package signIn;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class Manager {
	User current;
	Database database;
	
	public Manager() throws IOException{
		database = new Database();
	}
	
	//Creating the user
	void createUser(String name, String userName, String password, String dOB, String email, String ansOfSecurityQuestion) throws FileNotFoundException, IOException
	{
		boolean check = database.checkUser(userName);
		if(check != true){
			database.addUser(name,  userName,  password,  dOB,  email,  ansOfSecurityQuestion);
			System.out.println("created");
		}
	}
	
	//Removing the user
	void removeUser()
	{
		database.removeUser(current);
		current = null;
	}
	
	//Accessing the user
	boolean accessUser(String username, String password)
	{
		User temp = null;
		boolean access = database.validate(username, password);
		
		if(access == true)
			temp = database.getUser(username, password);
		if (temp != null) {
			System.out.print("not null");
			current = temp;
			return true;
		}
		else {
			return false;
		}
	}
	
	//Adding Friend
	void addFriend(User friend)
	{
		friend.addRequest(current);
	}
	
	//Searching a user
	//User search(String user)
	//{
		//return database.search(user);
	//}
	
	//Removing the friend
	void removeFriend(User friend)
	{
		current.removeFriend(friend);
		friend.removeFriend(current);
	}
	
	/*
	 * This funtion cannot be implemented now due to lack of data
	void compare(User, User)
	{
		
	}
	*/
	
	//Validating if the user is in the database
	boolean validate(String username, String password){
		
		if(database.validate(username, password) == true)
			return true;
		return false;
	}
}