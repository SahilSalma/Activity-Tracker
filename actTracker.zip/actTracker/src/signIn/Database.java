package signIn;
import java.io.*;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class Database{
	XSSFWorkbook workbook;
	Sheet sheet;
	public User sample;
	public ArrayList<User> users = new ArrayList<User>();
	
	public Database() throws IOException {
		try {
			FileInputStream file= new FileInputStream("testworkbook.xlsx");
			System.out.println("worked");
			workbook = new XSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);
			int y = sheet.getPhysicalNumberOfRows() - 1;
			System.out.println(y);
			
			// Getting users from excel file
			for(int i = 0; i < y; i++) {
				
				Row row = sheet.getRow(i);
				if(row != null) {
				System.out.println(row.getCell(0));
				System.out.println(row.getPhysicalNumberOfCells()+"\n");
				String name = row.getCell(0).toString();
				String username = row.getCell(1).toString();
				String password = row.getCell(2).toString();
				String dob = row.getCell(3).toString();
				String email = row.getCell(4).toString();
				String securityQn = row.getCell(5).toString();
				
			sample = new User(name,username,password,dob,email,securityQn);
			users.add(sample);
				}
			}
		for(Row row : sheet) {
			if(row == null)
				sheet.removeRow(row);
		}
			
		}
		finally {
		}
	}
	

	
	void getusers() {
		for(User u : users) {
			System.out.print(u.getName());
		}
	}

	void printUser() {
		for(User u : users) {
			System.out.print(u.getName()+ " "+ u.getPassword()+" "+ u.getEmail()+" "+ u.getDOB()+ "\n");
			
		}
	}
	
	
	boolean checkLogin(String username, String password) {
		 Row userRow = sheet.getRow(0);
		 Row passRow = sheet.getRow(1);
		 int check = 0;
		 
		 for(Cell c: userRow) {
			String temp = c.toString();

			if (temp.equals(username)) {
				System.out.print("True");
				check++;
			}	
		}
		for(Cell c : passRow) {
			String temp = c.toString();
			if(temp.equals(password)) {
				System.out.print("True");
				check++;
			}
		}
		if(check == 2)
			return true;
		return false;	
	}
	
	void removeUser(User user) {
		for(Row row: sheet) {
			if(row.getCell(1).toString() == user.getUserName()) {
				sheet.removeRow(row);
			}
		
		}
	}
	void Searcher() {
		
	}
	
	public void addUser(String name,String username, String password, String email, String dob, String secQn) throws FileNotFoundException, IOException {
        User temp = new User(name,username,password,email,dob,secQn);
		users.add(temp);
		Row row;
        Object[][] userToAdd = {
                {name,username,password,email,dob,secQn},
        };
        
        
        int rowCount = sheet.getPhysicalNumberOfRows() ;
        row = sheet.getRow(rowCount);
        
        while(row != null) {
        	rowCount++;
        	row = sheet.getRow(rowCount);
        }
        
        System.out.print(rowCount);
        row = sheet.createRow(rowCount);
        for (Object[] aBook : userToAdd) {
            int columnCount = 0;
             
            for (Object field : aBook) {
                Cell cell = row.createCell(columnCount++);
                if (field instanceof String) {
                    cell.setCellValue((String) field);
                } else if (field instanceof Integer){
                    cell.setCellValue((Integer) field);
                }
            }
             
        }
         
         
        try (FileOutputStream outputStream = new FileOutputStream("testworkbook.xlsx")) {
            workbook.write(outputStream);
        }
      
    }
	
	
}
